var xhr = new XMLHttpRequest();
var sites;
var sitesection;
var siteinfo;
var fea;
var feasection;
var faeinfo;
var transsite;
var catagory = "ButAll"; 
var rearrange = "ButHot";
var filarray;
var intfilarray = [0];
var search = [[0],[0]];
var filnum;
var music;
var musicsection;
var musicinfo;
var qodi;
var qodisection;
var qodiinfo;
var today = new Date();
var loadDay = today.getDay();
var newarray;
var knownalloy = "https://aa681d58-6554-4b06-8cdb-dd608d5bab11.id.repl.co/bobisyouruncle";
var knownalloydomain = "https://" + knownalloy.split("/")[2];
filarray = [0];
fetch('https://reblocked-1.gamk.repl.co/data/sites.csv')
  .then(response => response.text())
  .then((data) => {
    var dataedit1 = data.replaceAll('^', '<i class="h-3 indigo" stroke-width="4" data-feather="check"></i>');
    var dataedit2 = dataedit1.replaceAll('@', '<i class="h-3 indigo" stroke-width="4" data-feather="x"></i>');
    var dataedit3 = dataedit2.replaceAll('#', '<br>');
    var dataedit4 = dataedit3.replaceAll('%', knownalloy);
    var dataedit5 = dataedit4.replaceAll('~', knownalloydomain);
    sites = dataedit5.replaceAll('<a', '<a class="white" target="_blank"');
    sitesection = sites.split("\n");
    siteinfo = sites.split("\n").map(function(row){return row.split("$");}) 
    for (i = 0; i < sitesection.length - 1; i++) {
      document.getElementById('links').innerHTML += '<div class="w-100pc md-w-25pc"><div class="m-3 p-5 br-8 bg-indigo-lightest-10 overflow-hidden"><div class="p-3"><h3 class="indigo">' + siteinfo[i][2] + '</h3><div class="white flex items-center"><span class="fs-l1">' + siteinfo[i][1] + '</span></div></div><div class="p-3 indigo-lightest fw-400 fs-s1 lh-5">'+siteinfo[i][5]+'</div><div class="p-3"><a id="' + siteinfo[i][1] + '" href="' + siteinfo[i][3] + '" target="_blank"><button class="button full bg-black white  hover-opacity-100 hover-scale-up-1 ease-300">See Site</button></a></div></div>';
      transsite = siteinfo[i][1]
      document.getElementById(transsite).setAttribute("onClick", "SendLink(this.id)");
    }
    feather.replace();
})
fetch('https://reblocked-1.gamk.repl.co/data/news.csv')
  .then(response => response.text())
  .then((data) => {
    var news = data.split("\n");
    var h = 0;
    for (h = 0; h < news.length; h++) {
      document.getElementById('news').innerHTML += "- " + news[h] + "<br>";
    }
})
fetch('https://reblocked-1.gamk.repl.co/data/qodi.csv')
  .then(response => response.text())
  .then((data) => {
    qodi = data;
    var m = 0;
    qodisection = qodi.split("\n");
    qodiinfo = qodi.split("\n").map(function(row){return row.split("$");}) 
    var qdate = String(today.getMonth() + 1) + "/" + String(today.getDate()) + "/" + (String(today.getYear()) - 100);
    while (m < qodisection.length){
      if (qodiinfo[m][0] == qdate){
        document.getElementById("qodq").innerHTML = qodiinfo[m][1];
      }
      m++;
    }
})
fetch('https://reblocked-1.gamk.repl.co/data/memes.csv')
  .then(response => response.text())
  .then((data) => {
    var w = 0;
    var memesection = data.split("\n");
    var memeinfo = data.split("\n").map(function(row){return row.split("$");}) 
    var memedate = String(today.getMonth() + 1) + "/" + String(today.getDate()) + "/" + (String(today.getYear()) - 100);
    while (w < memesection.length){
      if (memeinfo[w][0] == memedate){
        document.getElementById("comment").innerHTML += memeinfo[w][2];
        document.getElementById("memes").src = memeinfo[w][1];
      }
      w++;
    }
})
function arrange(id)
{
  if (id == "ButHot"){rearrange = "ButHot";}
  if (id == "ButABC"){rearrange = "ButABC";}
  if (id == "ButNew"){rearrange = "ButNew";}
  if (id == "ButAll"){catagory = "ButAll";}
  if (id == "ButGames"){catagory = "ButGames";}
  if (id == "ButTools"){catagory = "ButTools";}
  document.getElementById('links').innerHTML = "";
  /*if (catagory == "ButAll") {
    if (rearrange == "ButHot") {

    }
    if (rearrange == "ButABC") {

    }
    if (rearrange == "ButNew") {

    }
  }*/
 if (catagory == "ButGames") { 
    filnum = 0;
    var g = 0;
    for (g = 0; g < sitesection.length - 1; g++) {
      if (siteinfo[g][2] ==  "Games"){
        filarray[filnum] = siteinfo[g][0];
        filnum++;
      }
    }
    if (rearrange == "ButHot") {
      for (var f = 0; f < filarray.length; f++) {
        for (g = 0; g < sitesection.length; g++){
          if (siteinfo[g][0] == filarray[f]) {
            intfilarray[f] = siteinfo[g][4]; 
          }
        }
      }
      intfilarray.sort(function(a, b) {
        return b - a;
      });
      var searchint = 0;
      for (var y = 0; y < intfilarray.length; y++) {
        for (var u = 0; u < sitesection.length - 1; u++){
          if (siteinfo[u][4] == intfilarray[y]){
            for (var p = 0; p < siteinfo[3].length; p++) {
              alert(siteinfo[u][p]);
              search[searchint][p] = siteinfo[u][p];
            }
            searchint++;
          }
        }
      } 
    } 
    /*if (rearrange == "ButABC") {

    }
    if (rearrange == "ButNew") {

    }*/
 }
  if (catagory == "ButTools") {
    filnum = 0;
    for (var j = 0; j < sitesection.length - 1; j++) {
      if (siteinfo[j][2] !=  "Games"){
        filarray[filnum] = j;
        alert(filarray[filnum]);
        filnum++;
      }
    }
    /*if (rearrange == "ButHot") {

    }
    if (rearrange == "ButABC") {

    }
    if (rearrange == "ButNew") {

    }*/
  }
  for (i = 0; i < sitesection.length - 1; i++) {
    document.getElementById('links').innerHTML += '<div class="w-100pc md-w-25pc"><div class="m-3 p-5 br-8 bg-indigo-lightest-10 overflow-hidden"><div class="p-3"><h3 class="indigo">' + siteinfo[i][2] + '</h3><div class="white flex items-center"><span class="fs-l1">' + siteinfo[i][1] + '</span></div></div><div class="p-3 indigo-lightest fw-400 fs-s1 lh-5">'+siteinfo[i][5]+'</div><div class="p-3"><a id="' + siteinfo[i][1] + '" href="' + siteinfo[i][3] + '" target="_blank"><button class="button full bg-black white  hover-opacity-100 hover-scale-up-1 ease-300">See Site</button></a></div></div>';
    transsite = siteinfo[i][1]
    document.getElementById(transsite).setAttribute("onClick", "SendLink(this.id)");
  }
  feather.replace();
}
setInterval(function() {
  var day = new Date();
  new Image().src = "https://reblocked-1.gamk.repl.co/img/unusedImage.png";
  new Image().src = knownalloydomain + "/assets/unusedImage.png";
  if (loadDay != day.getDay()) {location.reload();}
}, 600000);
function getCookie(cname) {
  let name = cname + "=";
  let decodedCookie = decodeURIComponent(document.cookie);
  let ca = decodedCookie.split(';');
  for(let i = 0; i <ca.length; i++) {
    let c = ca[i];
    while (c.charAt(0) == ' ') {
      c = c.substring(1);
    }
    if (c.indexOf(name) == 0) {
      return c.substring(name.length, c.length);
    }
  }
  return "";
}
if (window.location != "https://bbe0b560-ca4c-4940-9de8-688df8355bf4.id.repl.co/") {
  xhr.open("POST", "/admin", false);
  if(getCookie("admin") == "true"){
    xhr.send("true");
  } else {
    xhr.send("false");
  }
}
function SendLink (send){
  if(getCookie("admin") != "true"){
    xhr.open("POST", "/visits", false);
    xhr.send(send);
  }
}
function feedback(){
  var feedbox = document.getElementById("feedbacktxt");
  var feedinfo = document.getElementById("feedbackinfo");
  if(feedbox.value == ""){feedinfo.innerHTML = "Please actually submit something."}
  if(feedbox.value == "gaster"){feedinfo.innerHTML = "What? Did you expect that to do something?"}
  if(feedbox.value == "sans"){feedinfo.innerHTML = "Hiya, kid."}
  if(feedbox.value == "papyrus"){feedinfo.innerHTML = "I, THE GREAT PAPYRUS, WILL SOLVE THIS CONUNDRUM!"}
    if(feedbox.value != "gaster"){
      if(feedbox.value != "sans"){
        if(feedbox.value != "papyrus"){
          if(feedbox.value != ""){
            xhr.open("POST", "/feedback", false);
            xhr.send('"' + feedbox.value + '"');
            feedbox.value = "";
            feedinfo.innerHTML = "Submitted";
          }
        }
      }  
    } 
}
function qod() {
  var question = document.getElementById("qodq").innerHTML;
  var answer = document.getElementById("qoda").value;
  xhr.open("POST", "/qod", false);
  xhr.send("'" + question + "','" + answer + "'");
  document.getElementById("qodab").innerHTML = "<p>Submitted</p>";
}
function quickpoll() {
  var qpanswer = document.getElementById("qpanswer").value
  xhr.open("POST", "/quickpoll", false);
  xhr.send(qpanswer);
  document.getElementById("qpsub").innerHTML = "<p>Submitted</p>";
}